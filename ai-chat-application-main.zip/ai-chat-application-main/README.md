# 🤖 Spring Boot AI Chat Application

A real-time chat application built using **Spring Boot** and **WebSockets**, featuring a responsive frontend and an extensible AI integration layer.  
The project focuses on real-time communication, clean backend architecture, and frontend–backend interaction.

---

## ✨ Features

- 🔌 Real-time messaging using WebSockets (STOMP + SockJS)
- 👤 Simple username-based chat entry
- ⚡ Instant message broadcasting
- 🧠 Pluggable AI response service (extensible design)
- 🎨 Custom frontend UI with modern styling
- 🧩 Clean separation of config, controller, service, and model layers

---

## 🛠️ Tech Stack

### Backend
- ☕ Java 17
- 🌱 Spring Boot
- 🔄 Spring WebSocket (STOMP)
- 🧪 Spring Boot Test (optional)

### Frontend
- 🧾 HTML
- 🎨 CSS (custom theme)
- 📜 JavaScript
- 🔌 SockJS & STOMP.js

---

## 📁 Project Structure

The project follows a standard Spring Boot structure:

- `src/main/java/com/stanish/chatapp`
  - `config` – WebSocket configuration and event listeners
  - `controller` – Handles chat message routing
  - `service` – AI response service (extensible)
  - `model` – Chat message model
  - `ChatAppApplication.java` – Main Spring Boot application

- `src/main/resources`
  - `static/css` – Frontend styles
  - `static/js` – Frontend JavaScript logic
  - `static/index.html` – Chat UI
  - `application.properties` – Application configuration

- `pom.xml` – Maven dependencies and build configuration  
- `README.md` – Project documentation



---

## ▶️ How to Run the Project

### ✅ Prerequisites
- Java 17+
- Maven (or use Maven Wrapper)
- Git

---

### 🚀 Run with Maven Wrapper

From the project root:

```bash
./mvnw spring-boot:run

(Windows)

mvnw spring-boot:run

🌐 Access the App

Open your browser and go to:

http://localhost:9090


Enter a username and start chatting.

🧠 AI Integration Note

The project includes an AI service layer designed to be easily extended with:

Cloud-based AI APIs

Local language models

Mock or rule-based responses

This keeps the architecture flexible without coupling the app to a single provider.

🚧 Possible Enhancements

User authentication

Chat rooms

Message persistence (database)

AI provider switching

UI improvements (typing indicator, timestamps)

👤 Author

Stanish Appalo J A
📧 Email: stanishappaloja@gmail.com

📄 License

This project is created for learning and demonstration purposes.

