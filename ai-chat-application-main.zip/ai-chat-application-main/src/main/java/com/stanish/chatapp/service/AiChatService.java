package com.stanish.chatapp.service;

import com.stanish.chatapp.dto.OpenAiRequest;
import com.stanish.chatapp.dto.OpenAiResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class AiChatService {

    private final WebClient webClient;

    public AiChatService(
            @Value("${openai.api.key}") String apiKey,
            @Value("${openai.api.url}") String apiUrl) {

        this.webClient = WebClient.builder()
                .baseUrl(apiUrl)
                .defaultHeader("Authorization", "Bearer " + apiKey)
                .defaultHeader("Content-Type", "application/json")
                .build();
    }

    public String getAiResponse(String userMessage) {
        try {
            OpenAiRequest request = new OpenAiRequest(
                    "gpt-3.5-turbo",
                    List.of(new OpenAiRequest.Message("user", userMessage))
            );

            OpenAiResponse response = webClient.post()
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(OpenAiResponse.class)
                    .block();

            if (response == null ||
                response.getChoices() == null ||
                response.getChoices().isEmpty() ||
                response.getChoices().get(0).getMessage() == null) {

                return "I'm having trouble generating a response right now.";
            }

            return response.getChoices()
                    .get(0)
                    .getMessage()
                    .getContent()
                    .trim();

        } catch (Exception e) {
            // fallback so chat never breaks
            System.out.println("OpenAI error: " + e.getMessage());
            return "⚠️ AI service is currently unavailable. Please try again.";
        }
    }
}
