package com.stanish.chatapp.controller;

import com.stanish.chatapp.model.ChatMessage;
import com.stanish.chatapp.service.AiChatService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class ChatController {

    private final SimpMessagingTemplate messagingTemplate;
    private final AiChatService aiChatService;

    public ChatController(SimpMessagingTemplate messagingTemplate,
                          AiChatService aiChatService) {
        this.messagingTemplate = messagingTemplate;
        this.aiChatService = aiChatService;
    }

    @MessageMapping("/chat")
    public void handleMessage(ChatMessage message) {

        // send user message first
        ChatMessage userMessage = new ChatMessage();
        userMessage.setType(ChatMessage.MessageType.CHAT);
        userMessage.setSender(message.getSender());
        userMessage.setContent(message.getContent());
        messagingTemplate.convertAndSend("/topic/messages", userMessage);

        // generate AI response
        String aiReply = aiChatService.getAiResponse(message.getContent());

        ChatMessage aiMessage = new ChatMessage();
        aiMessage.setType(ChatMessage.MessageType.AI);
        aiMessage.setSender("AI Bot");
        aiMessage.setContent(aiReply);

        // small delay to keep message order natural
        new Thread(() -> {
            try {
                Thread.sleep(500);
                messagingTemplate.convertAndSend("/topic/messages", aiMessage);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }
}
