let stompClient = null;
let username = null;

function enterChat() {
    const name = document.getElementById("username").value.trim();

    if (name === "") {
        alert("Please enter your name");
        return;
    }

    username = name;

    document.querySelector(".login-container").style.display = "none";
    document.querySelector(".chat-container").style.display = "block";

    connect();
}

function connect() {
    const socket = new SockJS('/chat');
    stompClient = Stomp.over(socket);

    stompClient.connect({}, function () {
        stompClient.subscribe('/topic/messages', function (message) {
            showMessage(JSON.parse(message.body));
        });
    });
}

function sendMessage() {
    const messageInput = document.getElementById("message");
    const content = messageInput.value.trim();

    if (content === "") return;

    stompClient.send("/app/chat", {}, JSON.stringify({
        sender: username,
        content: content,
        type: "CHAT"
    }));

    messageInput.value = "";
}

function showMessage(message) {
    const chat = document.getElementById("chat");

    const messageElement = document.createElement("div");
    messageElement.className = "message";

    messageElement.innerHTML =
        `<strong>${message.sender}:</strong> ${message.content}`;

    chat.appendChild(messageElement);
    chat.scrollTop = chat.scrollHeight;
}
